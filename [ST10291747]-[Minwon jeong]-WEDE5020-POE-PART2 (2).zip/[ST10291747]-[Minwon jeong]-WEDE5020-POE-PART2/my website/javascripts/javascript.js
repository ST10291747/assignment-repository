function validateform()
{
    let x = document.forms['vale']["first name"].value;
    if (x =="") {
        alert("name must be filled out");
        return false;
    }
}

function validateform()
{
    let x = document.forms['vale']["last name"].value;
    if (x =="") {
        alert("name must be filled out");
        return false;
    }
}

function validateform()
{
    let x = document.forms['vale']["Subject"].value;
    if (x =="") {
        alert("Subject must be filled out");
        return false;
    }
}

function try_loops()
{
    var myNum = 10;

    while(myNum<15)
    {
        myNum++; // == mynum = mynum + 1;
        alert("we are inside the loop : number is" + myNum)

        if (myNum==15)
        {
            alert ("you are not suppoesd to be here: "= myNum) ;        
        }
    }

    alert("Here we are outside the loop" + myNum)
}